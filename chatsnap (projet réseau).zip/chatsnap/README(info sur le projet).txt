Projet réseau réalisé par Clément Loris et Julie. 

avant toutes exécution merci de changer le repertoire courant avec la commande (en modifiant la zone entre **):
	cd *chemin ver le dossier de téléchargement*\chatsnap\Le projet

Pour lancer le serveur → exécuter serveur_secure.py
Pour chaque client  → exécuter client_secure.py


Pour toutes question merci de nous contacter à l'adresse loris.lahon@protonmail.com




